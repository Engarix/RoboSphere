class DiffDriveKinematics:
    @staticmethod
    def calculate_wheel_speeds(v: float, omega: float):

        pendulum_speed = abs(v) * omega

        if v == 0:
            left_speed = v + omega
            right_speed = v - omega
        elif v == 1:
            left_speed = v * ((v-omega)//2 + (v-omega)%2)
            right_speed = v * ((v+omega)//2 + (v+omega)%2)
        elif v == -1:
            left_speed = v * (abs(v+omega)//2 + (v+omega)%2)
            right_speed = v * (abs(v-omega)//2 + (v-omega)%2)
        else:
            left_speed = 0
            right_speed = 0

        return left_speed, right_speed, pendulum_speed

    # 1 0 = l 1 r 1
    # 1 1 = l 0 r 1
    # 1 -1 = l 1 r 0

    # 0 0 = l 0 r 0
    # 0 1 = l 1 r -1
    # 0 -1 = l -1 r 1

    # -1 0 = l -1 r -1
    # -1 1 = l 0 r -1
    # -1 -1 = l -1 r 0
